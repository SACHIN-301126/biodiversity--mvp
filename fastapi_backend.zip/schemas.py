from pydantic import BaseModel

class SpeciesCreate(BaseModel):
    name: str
    description: str
