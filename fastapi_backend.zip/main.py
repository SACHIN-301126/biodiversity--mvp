from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
import models, schemas

# Initialize FastAPI
app = FastAPI()

# Create tables in the database
Base.metadata.create_all(bind=engine)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def read_root():
    return {"message": "Welcome to the AI-Powered Biodiversity Restorer API"}

@app.post("/add_species/")
def add_species(species: schemas.SpeciesCreate, db: Session = Depends(get_db)):
    db_species = models.Species(name=species.name, description=species.description)
    db.add(db_species)
    db.commit()
    db.refresh(db_species)
    return db_species
